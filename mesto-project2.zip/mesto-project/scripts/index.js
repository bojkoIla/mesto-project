// Константы
const initialCards = [
    {
      name: 'Эльбрус',
        link: 'https://ru.sott.net/image/s33/678788/эльбрус.jpg',
        likes: 5
    },
    {
      name: 'Белуха',
        link: 'https://avatars.mds.yandex.net/i?id=53933ab0d02b53823ac46eb4596cce47_l-4034313-images-thumbs&n=13',
        likes: 3
    },
    {
      name: 'Фишт',
        link: 'https://static.foto.ru/foto/images/photos/000/001/238/1238119_image_origin.jpg?1705160317',
        likes: 7
    },
    {
      name: 'Зуб Дракона',
        link: 'https://newsmiass.ru/news/2015/12/18/40297/8.jpg',
        likes: 2
    },
    {
      name: 'Ключевская сопка',
        link: 'https://vsegda-pomnim.com/uploads/posts/2022-05/1651425611_5-vsegda-pomnim-com-p-vulkan-klyuchevskoi-foto-5.jpg',
      likes: 9
    },
    {
      name: 'Казбек',
        link: 'https://avatars.mds.yandex.net/get-altay/5245944/2a0000017b2bb487efaf14c15b4a0131a281/orig',
        likes: 6
    }
  ];

// Функция для открытия попапа
function openPopup(popup) {
    popup.classList.add('popup_opened');
    document.addEventListener('keydown', closeByEscape);
}

// Функция для закрытия попапа
function closePopup(popup) {
    popup.classList.remove('popup_opened');
    document.removeEventListener('keydown', closeByEscape);
}

// Закрытие попапа по Esc
function closeByEscape(evt) {
    if (evt.key === 'Escape') {
        const openedPopup = document.querySelector('.popup_opened');
        closePopup(openedPopup);
    }
}

// Обработчики для попапов
document.addEventListener('DOMContentLoaded', function () {
    // Получаем элементы
    const avatarEditButton = document.querySelector('.profile__avatar-edit-button');
    const avatarPopup = document.querySelector('.popup_type_avatar');
    const avatarForm = avatarPopup.querySelector('.popup__form');
    const avatarInput = avatarPopup.querySelector('.popup__input_type_avatar');
    const profileAvatar = document.querySelector('.profile__avatar');
    const closeButtons = document.querySelectorAll('.popup__close-button');

    // Открытие попапа аватара
    avatarEditButton.addEventListener('click', function () {
        openPopup(avatarPopup);
    });

    // Обработка формы аватара
    avatarForm.addEventListener('submit', function (evt) {
        evt.preventDefault();
        profileAvatar.src = avatarInput.value;
        closePopup(avatarPopup);
        avatarForm.reset();
    });

    // Закрытие попапов по кнопке
    closeButtons.forEach(button => {
        const popup = button.closest('.popup');
        button.addEventListener('click', () => closePopup(popup));
    });

    // Закрытие попапов по клику на оверлей
    document.querySelectorAll('.popup').forEach(popup => {
        popup.addEventListener('click', (evt) => {
            if (evt.target === popup) {
                closePopup(popup);
            }
        });
    });
});

  // DOM элементы
  const profileName = document.querySelector('.profile__name');
  const profileDescription = document.querySelector('.profile__description');
  const profileEditButton = document.querySelector('.profile__edit-button');
  const profileAddButton = document.querySelector('.profile__add-button');
  const placesList = document.querySelector('.places__list');


// DOM элементы ава
const profileAvatar = document.querySelector('.profile__avatar');
const avatarEditButton = document.querySelector('.profile__avatar-edit-button');
const avatarPopup = document.querySelector('.popup_type_avatar');
const avatarForm = document.forms['avatar-form'];
const avatarLinkInput = avatarForm.querySelector('.popup__input_type_avatar');

// Проверка URL изображения
function isValidImageUrl(url) {
    return /\.(jpeg|jpg|gif|png|webp)$/.test(url.toLowerCase());
}

// Обработка формы аватара
function handleAvatarFormSubmit(evt) {
    evt.preventDefault();
    const errorElement = avatarForm.querySelector('.popup__error_type_avatar');

    // Валидация URL
    if (!isValidImageUrl(avatarLinkInput.value)) {
        errorElement.textContent = 'Ссылка должна вести на изображение (jpg, png, gif, webp)';
        errorElement.classList.add('popup__error_visible');
        return;
    }

    // Проверка загрузки изображения
    const testImage = new Image();
    testImage.src = avatarLinkInput.value;

    testImage.onload = function () {
        errorElement.classList.remove('popup__error_visible');
        profileAvatar.src = avatarLinkInput.value;
        closeModal(avatarPopup);
        avatarForm.reset();
    };

    testImage.onerror = function () {
        errorElement.textContent = 'Не удалось загрузить изображение. Проверьте ссылку.';
        errorElement.classList.add('popup__error_visible');
    };
}

// Обработчики событий
avatarEditButton.addEventListener('click', () => {
    const errorElement = avatarForm.querySelector('.popup__error_type_avatar');
    errorElement.classList.remove('popup__error_visible');
    avatarLinkInput.value = '';
    openModal(avatarPopup);
});

avatarForm.addEventListener('submit', handleAvatarFormSubmit);

// Запасной вариант при ошибке загрузки
profileAvatar.onerror = function () {
    this.src = './images/default-avatar.jpg';
};

  // Попапы
  const profilePopup = document.querySelector('.popup_type_edit');
  const cardPopup = document.querySelector('.popup_type_new-card');
  const imagePopup = document.querySelector('.popup_type_image');
  
  // Формы
  const profileForm = document.forms['profile-form'];
  const cardForm = document.forms['card-form'];
  
  // Инпуты форм
  const nameInput = profileForm.querySelector('.popup__input_type_name');
  const descriptionInput = profileForm.querySelector('.popup__input_type_description');
  const cardNameInput = cardForm.querySelector('.popup__input_type_card-name');
  const cardLinkInput = cardForm.querySelector('.popup__input_type_card-link');
  
  // Элементы попапа с картинкой
  const popupImage = imagePopup.querySelector('.popup__image');
  const popupCaption = imagePopup.querySelector('.popup__caption');
  
  // Шаблон карточки
  const cardTemplate = document.querySelector('#card-template').content;
  
  // Функции
  function openModal(popup) {
    popup.classList.add('popup_is-opened');
    document.addEventListener('keydown', closeModalByEscape);
  }
  
  function closeModal(popup) {
    popup.classList.remove('popup_is-opened');
    document.removeEventListener('keydown', closeModalByEscape);
  }
  
  function closeModalByEscape(evt) {
    if (evt.key === 'Escape') {
      const openedPopup = document.querySelector('.popup_is-opened');
      closeModal(openedPopup);
    }
  }
  
  function closeModalByOverlay(evt) {
    if (evt.target === evt.currentTarget) {
      closeModal(evt.currentTarget);
    }
  }
  
  function handleProfileFormSubmit(evt) {
    evt.preventDefault();
    profileName.textContent = nameInput.value;
    profileDescription.textContent = descriptionInput.value;
    closeModal(profilePopup);
  }
  
function handleCardFormSubmit(evt) {
    evt.preventDefault();
    const newCard = {
        name: cardNameInput.value,
        link: cardLinkInput.value,
        likes: 0 // Новые карточки начинаются с 0 лайков
    };
    placesList.prepend(createCard(newCard));
    cardForm.reset();
    closeModal(cardPopup);
}
  
function createCard(cardData) {
    const cardElement = cardTemplate.querySelector('.card').cloneNode(true);
    const cardImage = cardElement.querySelector('.card__image');
    const cardTitle = cardElement.querySelector('.card__title');
    const likeButton = cardElement.querySelector('.card__like-button');
    const likeCounter = cardElement.querySelector('.card__like-counter');
    const deleteButton = cardElement.querySelector('.card__delete-button');

    cardImage.src = cardData.link;
    cardImage.alt = cardData.name;
    cardTitle.textContent = cardData.name;
    likeCounter.textContent = cardData.likes || '0'; // Используем переданное значение или 0

    likeButton.addEventListener('click', () => {
        likeButton.classList.toggle('card__like-button_is-active');

        // Обновляем счетчик лайков
        let currentLikes = parseInt(likeCounter.textContent);
        if (likeButton.classList.contains('card__like-button_is-active')) {
            currentLikes += 1;
        } else {
            currentLikes -= 1;
        }
        likeCounter.textContent = currentLikes;
    });

    deleteButton.addEventListener('click', () => {
        cardElement.remove();
    });

    cardImage.addEventListener('click', () => {
        popupImage.src = cardData.link;
        popupImage.alt = cardData.name;
        popupCaption.textContent = cardData.name;
        openModal(imagePopup);
    });

    return cardElement;
}
  
  // Обработчики событий
  profileEditButton.addEventListener('click', () => {
    nameInput.value = profileName.textContent;
    descriptionInput.value = profileDescription.textContent;
    openModal(profilePopup);
  });
  
  profileAddButton.addEventListener('click', () => {
    openModal(cardPopup);
  });
  
  profileForm.addEventListener('submit', handleProfileFormSubmit);
  cardForm.addEventListener('submit', handleCardFormSubmit);
  
  // Закрытие попапов по клику на оверлей и крестик
  document.querySelectorAll('.popup').forEach(popup => {
    popup.addEventListener('click', closeModalByOverlay);
    popup.querySelector('.popup__close-button').addEventListener('click', () => closeModal(popup));
  });
  
  // Добавление анимации для попапов
  document.querySelectorAll('.popup').forEach(popup => {
    popup.classList.add('popup_is-animated');
  });
  
  // Рендер начальных карточек
  initialCards.forEach(card => {
    placesList.append(createCard(card));
  });